# Computação Gráfica
Projeto desenvolvido para a matéria de Computação Gráfica, utilizando OpenGL e FreeGlut 

integrantes
-Adjailson Freire de Sá Filho ,matricula:20223002120 
-Mateus Gonçalves Soares, matricula:20223003314
-Matheus Costa de Menezes, matricula:20223003234
-Lucas Andrade Brandão, matricula:20223002540
-Laura Pianetti Veloso, matricula:20223002424
-Gustavo De Assis Xavier, matricula:20223003379


#TODO

Para executar o jogo digite no terminal dentro dessa pasta "make run".




#Bibliotecas adicionais
-freeglut
-soil

para instalar a freeglut no linux digite no terminal "sudo apt-get install libglut3-dev"

para instalar a soil no linux digite no terminal "sudo apt-get install libsoil-dev"

