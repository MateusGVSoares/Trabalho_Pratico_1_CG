#ifndef __TEXT__
#define __TEXT__

#include <GL/glut.h>

void print(const char *text, void *font, float x, float y, GLuint red, GLuint green, GLuint blue, GLuint alpha);


#endif